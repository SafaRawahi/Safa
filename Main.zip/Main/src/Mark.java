import java.util.Scanner;

public class Mark {

   
     int markOfTest1;
    int markOfTest2;
    private int markOfAssignment1;
    private int markOfAssignment2;
    
    
    
    public void setmarkOfTest1(int markOfTest1)
    {
      this.markOfTest1 = markOfTest1;

      //System.out.println ("enter Test1 Mark");
    }

    public int getmarkOfTest1()
    {
      return markOfTest1;
    
    }
    public void setmarkOfTest2(int markOfTest2)
    {
      this.markOfTest2 = markOfTest2;

      //System.out.println ("enter Test2 Mark");
    }

    public int getmarkOfTest2()
    {
      return markOfTest2;
    
    }
    public void setmarkOfAssignment1(int markOfAssignment1)
    {
      this.markOfAssignment1 = markOfAssignment1;

      //System.out.println ("enter Assignment1 Mark");
    }

    public int getmarkOfAssignment1()
    {
      return markOfAssignment1;
    
    }
    public void setmarkOfAssignment2(int markOfAssignment2)
    {
      this.markOfAssignment2 = markOfAssignment2;

      //System.out.println ("enter Assignment2 Mark");
    }

    public int getmarkOfAssignment2()
    {
      return markOfAssignment2;
    
    }

    
}  